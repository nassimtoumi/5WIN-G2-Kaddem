package tn.esprit.spring.khaddem.entities;

public enum Specialite {
    IA,RESEAU,CLOUD,SECURITE
}
