package tn.esprit.spring.khaddem.entities;

public enum Niveau {
    JUNIOR,SENIOR,EXPERT
}
