package tn.esprit.spring.khaddem.entities;

public enum Option {
    GAMIX,SE,SAE,INFINI
}
